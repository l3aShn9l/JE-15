package com.example.healthcare.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Data
@Table(name = "ticket")
@Getter
@Setter
@ToString
@RequiredArgsConstructor
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "flight")
    private Flight flight;

    @ManyToOne
    @JoinColumn(name = "passenger")
    private Passenger passenger;



}