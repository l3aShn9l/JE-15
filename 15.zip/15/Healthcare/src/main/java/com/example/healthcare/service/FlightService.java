package com.example.healthcare.service;

import com.example.healthcare.entity.Flight;
import com.example.healthcare.repository.FlightRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class FlightService {

    private final FlightRepository flightRepository;


    public Flight getFlightById(Long orderId) {
        return flightRepository.findById(orderId).orElse(null);
    }
}
